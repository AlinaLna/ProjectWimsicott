package model.card;

import model.type.PassiveType;

public abstract class EquipmentCard extends Card {

    private int attackPoint;
    private int defendPoint;
    private PassiveType passiveType;

    public EquipmentCard() {
    }

    public EquipmentCard(String name, int price, String desctiption, int attackPoint, int defendPoint, PassiveType passiveType) {
        super(name, price, desctiption);
        this.attackPoint = attackPoint;
        this.defendPoint = defendPoint;
        this.passiveType = passiveType;
    }

    public int getAttackPoint() {
        return attackPoint;
    }

    public void setAttackPoint(int attackPoint) {
        this.attackPoint = attackPoint;
    }

    public int getDefendPoint() {
        return defendPoint;
    }

    public void setDefendPoint(int defendPoint) {
        this.defendPoint = defendPoint;
    }

    public PassiveType getPassiveType() {
        return passiveType;
    }

    public void setPassiveType(PassiveType passiveType) {
        this.passiveType = passiveType;
    }

    public abstract void active(HeroCard active, HeroCard opponent);
}
