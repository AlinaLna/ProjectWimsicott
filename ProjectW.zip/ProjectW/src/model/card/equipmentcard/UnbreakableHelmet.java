/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.card.equipmentcard;

import model.card.EquipmentCard;
import model.card.HeroCard;
import model.type.PassiveType;

/**
 *
 * @author mew3d
 */
public class UnbreakableHelmet extends EquipmentCard{

    private boolean activated = false;

    public UnbreakableHelmet() {
        super("UnbreakableHelmet", 3, "Block one attack damage (can not block the effect and damage increase from passive of enemy equipment).", 2, 4, PassiveType.DEFEND);
    }

    @Override
    public void active(HeroCard active, HeroCard opponent) {
        if(!activated){
            // get bonus attack from equipment of enemy
            int bonus = 0;
            if(opponent.getEquipment() != null)
                bonus = opponent.getEquipment().getAttackPoint();
            // increasing hp of hero = atk(enemy) + atk(enemy eqm)
            bonus += opponent.getAttackPoint();
            active.setDefendPoint(active.getDefendPoint() + bonus);
            activated = true;
            System.out.println(active.getName() + " was blocked " + bonus + " damage.");
        }
    }
    
}
