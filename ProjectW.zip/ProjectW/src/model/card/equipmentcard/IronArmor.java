/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.card.equipmentcard;

import model.card.EquipmentCard;
import model.card.HeroCard;
import model.type.PassiveType;

/**
 *
 * @author mew3d
 */
public class IronArmor extends EquipmentCard{

    public IronArmor() {
        super("IronArmor", 4, "Increase 2 defend point when attacking", 1, 5, PassiveType.ATTACK);
    }

    @Override
    public void active(HeroCard active, HeroCard opponent) {//NONE -> HeroCard = null
        active.setDefendPoint(active.getDefendPoint() + 2);
        System.out.println(active.getName() + " increased 2 def.");
    }
    
}
