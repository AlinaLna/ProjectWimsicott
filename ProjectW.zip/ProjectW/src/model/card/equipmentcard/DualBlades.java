/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.card.equipmentcard;

import model.card.EquipmentCard;
import model.card.HeroCard;
import model.type.PassiveType;

/**
 *
 * @author mew3d
 */
public class DualBlades extends EquipmentCard{

    public DualBlades() {
        super("DualBlades", 5, "Attack 2 turn on one enemy (second turn will be disable if enemy fainted after first turn).", 3, 0, PassiveType.ATTACK);
    }

    @Override
    public void active(HeroCard active, HeroCard opponent) {
        //get defend point and equipment card to check is IronAmor
        int statDef = opponent.getDefendPoint();
        if (opponent.getEquipment() != null){
            statDef += opponent.getEquipment().getDefendPoint();
        }
        int statAtk = active.getAttackPoint();
        if(active.getEquipment() != null){
            statAtk += active.getEquipment().getAttackPoint();
        }
        //attacking
        if(statAtk < statDef){
            opponent.setDefendPoint(opponent.getDefendPoint() - statAtk);
        }
    }
    
}
