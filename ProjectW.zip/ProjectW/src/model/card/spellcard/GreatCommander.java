/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.card.spellcard;

import model.OnBoard;
import model.card.HeroCard;
import model.card.SpellCard;
import model.type.SpellTarget;

public class GreatCommander extends SpellCard {

    public GreatCommander() {
        super("GreatCommander", 2, "Increase allies attack point by 1.", SpellTarget.NONE);
    }

    @Override
    public void cast(HeroCard target) {
        HeroCard[] handle = OnBoard.getBoard().getActivePlayer().getOffHandle();
        for (HeroCard card : handle) {
            if (card != null) {
                card.setAttackPoint(card.getAttackPoint() + 1);
            }
        }
        System.out.println("Your team have been increase 1 attack point.");
    }

}
