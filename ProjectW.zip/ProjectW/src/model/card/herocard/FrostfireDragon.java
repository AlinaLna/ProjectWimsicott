package model.card.herocard;

import model.card.HeroCard;

public class FrostfireDragon extends HeroCard {
    public FrostfireDragon() {
        super("FrostfireDragon", 5, "A legendary dragon that commands the opposing forces of ice and flame.", 4, 8);
    }
}