/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.card.herocard;

import model.card.HeroCard;

/**
 *
 * @author mew3d
 */
public class MountainThief extends HeroCard {
    //String name, int price, String desctiption, int attackPoint, int defendPoint
    public MountainThief() {
        super("MountainThief",  2, "A danger theif living on mountain.", 3, 7);
    }

}
