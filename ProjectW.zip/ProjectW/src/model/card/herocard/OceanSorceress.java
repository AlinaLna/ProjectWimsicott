package model.card.herocard;

import model.card.HeroCard;

public class OceanSorceress extends HeroCard {
    public OceanSorceress() {
        super("OceanSorceress", 5, "A mystical being of the deep seas.", 6, 4);
    }
}