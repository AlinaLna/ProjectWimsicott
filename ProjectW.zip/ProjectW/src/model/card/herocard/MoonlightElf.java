package model.card.herocard;

import model.card.HeroCard;

public class MoonlightElf extends HeroCard {
    public MoonlightElf() {
        super("MoonlightElf", 4, "A graceful elf that draws power from the moon and stars.", 5, 4);
    }
}