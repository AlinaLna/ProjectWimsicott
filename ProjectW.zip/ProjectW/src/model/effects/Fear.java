package model.effects;

import model.card.HeroCard;

/**
 *
 *
 * @author Vo Hoang
 */
public class Fear extends Effects {

    public Fear() {

    }

    @Override
    public void action(HeroCard target) {
        if (target.getAttackPoint() > 1) {
            target.setAttackPoint(target.getAttackPoint() - 1);
            System.out.println(target.getName() + " decreases 1 ATK!");
        }
    }
}
