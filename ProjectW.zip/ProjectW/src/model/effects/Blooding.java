package model.effects;

import model.card.HeroCard;

public class Blooding extends Effects{

    public Blooding() {
    }

    @Override
    public void action(HeroCard target) {
        target.setDefendPoint(target.getDefendPoint()-1);
        System.out.println(target.getName() + " was bleed.");
    }
    
}
