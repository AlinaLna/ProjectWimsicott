package model.effects;

import model.card.HeroCard;

/**
 *
 *
 * @author Vo Hoang
 */
public class Poison extends Effects {

    private int turnLeft = 3;

    public Poison() {

    }

    @Override
    public void action(HeroCard target) {

        if (turnLeft > 0) {
            target.setDefendPoint(target.getDefendPoint() - 1);
            turnLeft--;
            System.out.println(target.getName() + " was postioned!");
        }
    }

}
