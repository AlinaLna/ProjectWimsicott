package model.type;

public enum TurnQueue {
    ACTIVE, OPPONENT, WAIT;
}
