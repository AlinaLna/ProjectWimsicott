package model;

import model.card.Deck;
import model.card.MainDeck;

public class Board {
    private Player activePlayer = new Player();
    private Player opponentPlayer = new Player();
    private Deck mainDeck = new MainDeck();
    
    public Board() {
    }

    public Player getActivePlayer() {
        return activePlayer;
    }

    public void setActivePlayer(Player activePlayer) {
        this.activePlayer = activePlayer;
    }

    public Player getOpponentPlayer() {
        return opponentPlayer;
    }

    public void setOpponentPlayer(Player opponentPlayer) {
        this.opponentPlayer = opponentPlayer;
    }

    public Deck getMainDeck() {
        return mainDeck;
    }

    public void setMainDeck(Deck mainDeck) {
        this.mainDeck = mainDeck;
    }

}
