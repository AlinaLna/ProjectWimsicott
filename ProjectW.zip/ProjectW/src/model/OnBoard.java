package model;

public class OnBoard {
    public static Board board = new Board();
    
    public static Board getBoard(){
        return board;
    }
}
